from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator


class QueryConstraints(BaseModel):
    nearest: bool = True
    near: Optional[str] = None
    location: Optional[str] = None
    top_k: int = 5
    min_confidence: float = 0.0

    @field_validator("top_k")
    @classmethod
    def validate_top_k(cls, value: int) -> int:
        if value < 1:
            raise ValueError("top_k must be >= 1")
        return value


class QueryRequest(BaseModel):
    raw_query: str = Field(..., description="Original natural-language user query")
    intent: Literal["locate_object", "describe_scene", "list_objects"] = "locate_object"
    object_name: Optional[str] = None
    attributes: Dict[str, Any] = Field(default_factory=dict)
    constraints: QueryConstraints = Field(default_factory=QueryConstraints)


class CandidateObject(BaseModel):
    image_filename: str
    object_id: int
    type: str
    confidence: float
    semantic_score: float
    combined_score: float
    attributes: Dict[str, Any]
    boundaries: Dict[str, Any]
    position_x: Optional[float] = None
    position_y: Optional[float] = None
    orientation_yaw: Optional[float] = None
    sequence_number: Optional[int] = None
    relative_description: str


class QueryResponse(BaseModel):
    status: Literal["success", "error"]
    query: str
    intent: str
    parsed_object: Optional[str] = None
    matched_object: Optional[str] = None
    navigation_hint: Optional[str] = None
    best_image: Optional[str] = None
    candidates: List[CandidateObject] = Field(default_factory=list)
    message: str
