from __future__ import annotations

import math
from pathlib import Path
from typing import Optional

from .indexer import build_index
from .parser import parse_query
from .retrieval import SemanticRetriever
from .schemas import CandidateObject, QueryRequest, QueryResponse


class NavigationService:
    def __init__(self, detection_dir: str | Path, db_path: str | Path):
        self.detection_dir = Path(detection_dir)
        self.db_path = Path(db_path)
        self.retriever: Optional[SemanticRetriever] = None

    def initialize(self, rebuild: bool = False) -> int:
        if rebuild or not self.db_path.exists():
            count = build_index(self.detection_dir, self.db_path)
        else:
            count = -1
        self.retriever = SemanticRetriever(str(self.db_path))
        return count

    def _ensure_ready(self) -> None:
        if self.retriever is None:
            self.initialize(rebuild=False)

    @staticmethod
    def _relative_description(x: Optional[float], y: Optional[float], location_hint: Optional[str]) -> str:
        if x is None or y is None:
            return location_hint or "location unavailable"
        horizontal = "right" if x > 0 else "left"
        depth = "ahead" if y > 0 else "behind"
        return f"approximately {abs(x):.2f}m to the {horizontal} and {abs(y):.2f}m {depth}"

    @staticmethod
    def _navigation_hint(x: Optional[float], y: Optional[float]) -> str:
        if x is None or y is None:
            return "Navigation hint unavailable because pose data is missing."
        parts = []
        if abs(y) > 0.05:
            parts.append(f"move {'forward' if y > 0 else 'backward'} {abs(y):.2f} meters")
        if abs(x) > 0.05:
            parts.append(f"then move {'right' if x > 0 else 'left'} {abs(x):.2f} meters")
        return ", ".join(parts) if parts else "You are already at the target location."

    def query(self, request: QueryRequest | str) -> QueryResponse:
        self._ensure_ready()
        if isinstance(request, str):
            request = parse_query(request)

        if request.intent != "locate_object":
            return QueryResponse(
                status="error",
                query=request.raw_query,
                intent=request.intent,
                message="This Stage II implementation currently supports locate_object queries.",
            )

        if not request.object_name:
            return QueryResponse(
                status="error",
                query=request.raw_query,
                intent=request.intent,
                message="Could not extract a target object from the query.",
            )

        query_text = " ".join(
            [request.object_name] + [f"{k} {v}" for k, v in request.attributes.items()]
        )
        hits = self.retriever.search(
            query_text,
            top_k=request.constraints.top_k,
            min_confidence=request.constraints.min_confidence,
            near=request.constraints.near,
            requested_attributes=request.attributes,
        )
        if not hits:
            return QueryResponse(
                status="error",
                query=request.raw_query,
                intent=request.intent,
                parsed_object=request.object_name,
                message="No matching objects were found in the Stage I database.",
            )

        candidates = []
        for hit in hits:
            rel = self._relative_description(hit.position_x, hit.position_y, hit.attributes.get("location"))
            candidates.append(
                CandidateObject(
                    image_filename=hit.image_filename,
                    object_id=hit.object_id,
                    type=hit.type,
                    confidence=hit.confidence,
                    semantic_score=hit.semantic_score,
                    combined_score=hit.combined_score,
                    attributes=hit.attributes,
                    boundaries=hit.boundaries,
                    position_x=hit.position_x,
                    position_y=hit.position_y,
                    orientation_yaw=hit.orientation_yaw,
                    sequence_number=hit.sequence_number,
                    relative_description=rel,
                )
            )

        best = candidates[0]
        hint = self._navigation_hint(best.position_x, best.position_y)
        return QueryResponse(
            status="success",
            query=request.raw_query,
            intent=request.intent,
            parsed_object=request.object_name,
            matched_object=best.type,
            best_image=best.image_filename,
            navigation_hint=hint,
            candidates=candidates,
            message=(
                f"Best match is '{best.type}' in {best.image_filename} with confidence "
                f"{best.confidence:.2f} and semantic score {best.semantic_score:.2f}."
            ),
        )
