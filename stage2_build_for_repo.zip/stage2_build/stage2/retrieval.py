from __future__ import annotations

import json
import math
import sqlite3
from dataclasses import dataclass
from typing import Dict, List, Optional

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class RetrievedRow:
    image_filename: str
    object_id: int
    type: str
    confidence: float
    semantic_score: float
    combined_score: float
    attributes: Dict
    boundaries: Dict
    position_x: Optional[float]
    position_y: Optional[float]
    orientation_yaw: Optional[float]
    sequence_number: Optional[int]


class SemanticRetriever:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english")
        self.rows: List[sqlite3.Row] = []
        self.doc_matrix = None
        self._load_index()

    def _load_index(self) -> None:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM object_index").fetchall()
        conn.close()
        self.rows = list(rows)
        corpus = [row["object_text"] for row in self.rows] or [""]
        self.doc_matrix = self.vectorizer.fit_transform(corpus)

    def search(
        self,
        query_text: str,
        *,
        top_k: int = 5,
        min_confidence: float = 0.0,
        near: Optional[str] = None,
        requested_attributes: Optional[Dict] = None,
    ) -> List[RetrievedRow]:
        if not self.rows:
            return []

        requested_attributes = requested_attributes or {}
        query_vec = self.vectorizer.transform([query_text])
        sims = cosine_similarity(query_vec, self.doc_matrix).flatten()

        scored: List[RetrievedRow] = []
        for row, sim in zip(self.rows, sims):
            confidence = float(row["confidence"])
            if confidence < min_confidence:
                continue

            attr = json.loads(row["attributes_json"])
            bnd = json.loads(row["boundaries_json"])
            score = 0.7 * float(sim) + 0.3 * confidence

            if near:
                near_text = f"{row['type']} {attr.get('description', '')} {attr.get('location', '')}".lower()
                if near.lower() in near_text:
                    score += 0.15

            for key, value in requested_attributes.items():
                haystack = " ".join([str(row["type"]), json.dumps(attr)]).lower()
                if str(value).lower() in haystack:
                    score += 0.1
                else:
                    score -= 0.05

            distance_penalty = 0.0
            if row["position_x"] is not None and row["position_y"] is not None:
                distance_penalty = 0.02 * math.sqrt(row["position_x"] ** 2 + row["position_y"] ** 2)
                score -= distance_penalty

            scored.append(
                RetrievedRow(
                    image_filename=row["image_filename"],
                    object_id=int(row["object_id"]),
                    type=row["type"],
                    confidence=confidence,
                    semantic_score=float(sim),
                    combined_score=float(score),
                    attributes=attr,
                    boundaries=bnd,
                    position_x=row["position_x"],
                    position_y=row["position_y"],
                    orientation_yaw=row["orientation_yaw"],
                    sequence_number=row["sequence_number"],
                )
            )

        scored.sort(key=lambda x: x.combined_score, reverse=True)
        return scored[:top_k]
