from __future__ import annotations

import json
from pathlib import Path

from stage2.indexer import build_index
from stage2.parser import parse_query
from stage2.service import NavigationService


SAMPLE = {
    "objects_detected": [
        {
            "object_id": 1,
            "type": "painting",
            "attributes": {
                "description": "A colorful painting hanging on the wall",
                "color": "various",
                "size": "large",
                "location": "wall"
            },
            "confidence": 0.92,
            "boundaries": {"lower_x": 50, "lower_y": 100, "upper_x": 150, "upper_y": 200}
        },
        {
            "object_id": 2,
            "type": "sliding doors",
            "attributes": {
                "description": "Tall sliding doors with frosted glass panels",
                "color": "black and frosted white",
                "size": "tall",
                "location": "right side of the room"
            },
            "confidence": 0.97,
            "boundaries": {"lower_x": 300, "lower_y": 100, "upper_x": 480, "upper_y": 480}
        }
    ],
    "image_dimensions": {"width": 640, "height": 480},
    "image_filename": "image_2024-07-02_11-09-12.jpg",
    "position_x": -0.86,
    "position_y": 0.90,
    "orientation_yaw": 3.09,
    "sequence_number": 0
}


def test_parser_extracts_object() -> None:
    parsed = parse_query("Where is the nearest painting?")
    assert parsed.object_name == "painting"
    assert parsed.intent == "locate_object"


def test_end_to_end_query(tmp_path: Path) -> None:
    detection_dir = tmp_path / "detection_results"
    detection_dir.mkdir()
    (detection_dir / "sample_detected.json").write_text(json.dumps(SAMPLE), encoding="utf-8")
    db_path = tmp_path / "stage2.db"

    rows = build_index(detection_dir, db_path)
    assert rows == 2

    service = NavigationService(detection_dir, db_path)
    service.initialize()
    response = service.query("Where is the nearest painting?")
    assert response.status == "success"
    assert response.matched_object == "painting"
    assert response.best_image == "image_2024-07-02_11-09-12.jpg"
