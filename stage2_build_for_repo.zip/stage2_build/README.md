# Stage II build for Perception-In-Robotics-Project-

This package completes **Stage II: user interaction system** on top of the Stage I outputs already present in the GitHub repo.

## What this Stage II implementation does

It reads the existing `detection_results/*_detected.json` files, normalizes them into a searchable SQLite index, parses natural-language user queries, retrieves the best semantic object matches, filters and reranks candidates, and returns navigation-friendly output with image references and pose-based hints.

## Why this fits your repo

The repo's Stage I outputs already contain the fields needed for Stage II, including:

- `objects_detected`
- `image_filename`
- `position_x`
- `position_y`
- `orientation_yaw`
- `sequence_number`

That is enough to build an end-to-end Stage II retrieval system without changing your Stage I generation format.

## Files added

- `stage2/schemas.py` - Pydantic models for requests and responses
- `stage2/parser.py` - natural-language query parser to structured request
- `stage2/indexer.py` - converts Stage I JSON outputs into a searchable SQLite DB
- `stage2/retrieval.py` - TF-IDF semantic retrieval and reranking
- `stage2/service.py` - end-to-end Stage II orchestration
- `stage2/api.py` - FastAPI app with `/parse` and `/query`
- `run_stage2.py` - CLI entry point
- `tests/test_stage2.py` - smoke tests

## Install

```bash
pip install -r requirements.txt
```

## Run from the repo root

Place these files in the root of your GitHub repo so the layout becomes:

```text
Perception-In-Robotics-Project-/
  detection_results/
  run_experiment.ipynb
  run_stage2.py
  requirements.txt
  stage2/
```

Then run:

```bash
python run_stage2.py --rebuild "Where is the nearest painting?"
```

Example response:

```json
{
  "status": "success",
  "query": "Where is the nearest painting?",
  "intent": "locate_object",
  "parsed_object": "painting",
  "matched_object": "painting",
  "best_image": "image_2024-07-02_11-09-12.jpg",
  "navigation_hint": "move forward 0.90 meters, then move left 0.86 meters",
  "message": "Best match is 'painting' in image_2024-07-02_11-09-12.jpg with confidence 0.92 and semantic score 0.63."
}
```

## Run as an API

```bash
uvicorn stage2.api:app --reload
```

Endpoints:

- `POST /parse`
- `POST /query`
- `GET /health`

Example request:

```bash
curl -X POST http://127.0.0.1:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Where is the nearest sliding door?"}'
```

## Design notes

This implementation follows the Stage II flow from the paper:

1. natural-language query input
2. JSON-like parsing
3. validation via schema
4. object extraction
5. semantic retrieval from the Stage I database
6. filtering and reranking
7. best image/object-instance selection
8. response generation with coordinates and navigation hints

## Limitations and next upgrades

This version uses TF-IDF semantic retrieval so it runs locally and does not require external APIs. Stronger upgrades you can add later:

- SentenceTransformer embeddings instead of TF-IDF
- OpenAI structured output parser for richer query understanding
- graph/path planning instead of direct pose hints
- room-level topological map
- multimodal re-ranking using the original images

## Recommended next repo commit message

```text
Add Stage II semantic query and navigation system on top of Stage I detection outputs
```
